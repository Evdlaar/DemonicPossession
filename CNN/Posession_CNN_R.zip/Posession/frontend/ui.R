library(shiny)
library(shinyjs)

fluidPage(
    useShinyjs(),

    titlePanel("Possession Classification"),

    sidebarLayout(
        sidebarPanel(
	    includeCSS('boot.css'),
	    tabsetPanel(
	       id = "tabs",
	       tabPanel("Welcome",
		h3("Welcome to the possession classification website!"),
		h5("This high-tech solution allows a user to automatically detect demonic possession through the upload of photo's!"),
	        img(src="exo_img.png", height = 483, width = 400)
		),
               tabPanel("Upload Image",
                  fileInput("img", "Choose image file", accept=c("image/jpeg")))
	       )),
        mainPanel(
	    h3(textOutput("pred"),
	    tags$hr(),
            HTML('<output id="list"></output>'),
            tags$hr())
            
        )
    )
)


