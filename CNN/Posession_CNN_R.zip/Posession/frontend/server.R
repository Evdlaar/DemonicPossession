library(shiny)
library(MicrosoftML)
library(imager)

# We are loading the trained model from the rdata file
load("../model.rdata")

cropImages <- function(x, fraction=0.1)
{
    ndim <- round(fraction * dim(x))
    imager::crop.borders(x, ndim[1], ndim[2])
}

resizeImages <- function(x, ndim=c(50, 50))
{
    imager::resize(x, ndim[1], ndim[2], dim(x)[3], dim(x)[4],
                   interpolation_type=4)
}


rotateImages <- function(x, angle=0)
{
    z <- imager::imrotate(x, angle)
    ndim <- (dim(z) - dim(x))/2
    imager::crop.borders(z, ndim[1], ndim[2])
}

processNewImage <- function(angle, files, chunkSize=10000)
{
    outPath <- file.path("C:/R/Posession/imgProcessedNew", angle)
    if(!dir.exists(outPath)) dir.create(outPath, recursive=TRUE)

    # do this in chunks to allow checkpointing
    n <- length(files)
    nChunks <- n%/%chunkSize + (n%%chunkSize != 0)

    res <- list()
    for(i in seq_len(nChunks))
    {
        message("doing rotation angle ", angle, ", chunk ", i)
        # vector of rows for this chunk
        this <- if(i != nChunks)
            chunkSize*(i - 1) + 1:chunkSize
        else chunkSize*(i - 1) + 1:(n%%chunkSize)

        thisChunk <- files[this]
        res[[i]] <- sapply(thisChunk, function(f, size, angle, path) {
                ri <- try(imager::load.image(f) %>%
                    cropImages(0.26) %>%
                    rotateImages(angle) %>%
                    resizeImages(c(50, 50)) %>%
                    imager::save.image(file.path(path, basename(f))))
                if(inherits(ri, "try-error"))
                    f
                else "0"
            },
            path=outPath, angle=angle, USE.NAMES=FALSE)
    }
    invisible(res)
}


function(input, output, session)
{

    # Remove the old images used for training the model
    unlink("C:/R/Posession/imgProcessedNew", recursive = TRUE)

    shinyjs::runjs(showImgJs)

    observeEvent(input$img, {
      inFile <- input$img
      if (is.null(inFile))
        return()
      file.copy(inFile$datapath, file.path("C:/R/Posession/imgTest", inFile$name) )
    
     # crop and rotate the new images
     imgFiles <- dir("C:/R/Posession/imgTest", pattern="\\.jpg$", full=TRUE)
     angle <- c(0, 45, 90)
     res <- lapply(angle, processNewImage, files=imgFiles)

     # create dataframe holding the files
     possessed <- c(0)
     id <- c(1)
     newImages <- dir("C:/R/Posession/imgProcessedNew", pattern = ".jpg$", recursive = TRUE, full=TRUE)

     newImagesDF <- data.frame(basename(newImages), as.integer(id), newImages, as.integer(possessed), stringsAsFactors=FALSE)
     names(newImagesDF) <- c("name", "id","path","possessed")

     # perform the prediction
     pred_new <- rxPredict(model, newImagesDF, extraVarsToWrite=c('name', 'path'))

     pred_new$possesed <- ifelse(as.character(pred_new$PredictedLabel)==0,"We're good, no signs of possession","POSSESSED!!!! Someone call an exorcist!")

     do.call(file.remove, list(list.files("C:/R/Posession/imgTest", full.names = TRUE)))
     unlink("C:/R/Posession/imgProcessedNew", recursive = TRUE)

     pred_final <- pred_new$possesed[1]

     output$pred <- renderText({
        if(is.null(input$img))
            return("")
        name <- input$img$name
        file <- input$img$datapath
        img <- paste0(as.character(readBin(file, raw(), file.size(file))), collapse="")

	out <- pred_final
       
	}) 

    })

    
}

