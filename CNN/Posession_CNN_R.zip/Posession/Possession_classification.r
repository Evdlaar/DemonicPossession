
# Install RMLtools if they aren't installed yet
# install.packages("devtools")
# devtools::install_github("andrie/RMLtools")

library(imager)
library(parallel)
library(MicrosoftML)
library(dplyr)
library(RMLtools)
library(sqlrutils)
library(mrsdeploy)

setwd("C:/R/Posession")

#############################################
# Create functions the modify the images    #
# for use in the CNN                        #
#############################################

cropImages <- function(x, fraction=0.1)
{
    ndim <- round(fraction * dim(x))
    imager::crop.borders(x, ndim[1], ndim[2])
}


resizeImages <- function(x, ndim=c(50, 50))
{
    imager::resize(x, ndim[1], ndim[2], dim(x)[3], dim(x)[4],
                   interpolation_type=4)
}


rotateImages <- function(x, angle=0)
{
    z <- imager::imrotate(x, angle)
    ndim <- (dim(z) - dim(x))/2
    imager::crop.borders(z, ndim[1], ndim[2])
}

processImage <- function(angle, files, chunkSize=10000)
{
    outPath <- file.path("C:/R/Posession/imgProcessed", angle)
    if(!dir.exists(outPath)) dir.create(outPath, recursive=TRUE)

    # do this in chunks to allow checkpointing
    n <- length(files)
    nChunks <- n%/%chunkSize + (n%%chunkSize != 0)

    res <- list()
    for(i in seq_len(nChunks))
    {
        message("doing rotation angle ", angle, ", chunk ", i)
        # vector of rows for this chunk
        this <- if(i != nChunks)
            chunkSize*(i - 1) + 1:chunkSize
        else chunkSize*(i - 1) + 1:(n%%chunkSize)

        thisChunk <- files[this]
        res[[i]] <- sapply(thisChunk, function(f, size, angle, path) {
                ri <- try(imager::load.image(f) %>%
                    cropImages(0.26) %>%
                    rotateImages(angle) %>%
                    resizeImages(c(50, 50)) %>%
                    imager::save.image(file.path(path, basename(f))))
                if(inherits(ri, "try-error"))
                    f
                else "0"
            },
            path=outPath, angle=angle, USE.NAMES=FALSE)
    }
    invisible(res)
}

processNewImage <- function(angle, files, chunkSize=10000)
{
    outPath <- file.path("C:/R/Posession/imgProcessedNew", angle)
    if(!dir.exists(outPath)) dir.create(outPath, recursive=TRUE)

    # do this in chunks to allow checkpointing
    n <- length(files)
    nChunks <- n%/%chunkSize + (n%%chunkSize != 0)

    res <- list()
    for(i in seq_len(nChunks))
    {
        message("doing rotation angle ", angle, ", chunk ", i)
        # vector of rows for this chunk
        this <- if(i != nChunks)
            chunkSize*(i - 1) + 1:chunkSize
        else chunkSize*(i - 1) + 1:(n%%chunkSize)

        thisChunk <- files[this]
        res[[i]] <- sapply(thisChunk, function(f, size, angle, path) {
                ri <- try(imager::load.image(f) %>%
                    cropImages(0.26) %>%
                    rotateImages(angle) %>%
                    resizeImages(c(50, 50)) %>%
                    imager::save.image(file.path(path, basename(f))))
                if(inherits(ri, "try-error"))
                    f
                else "0"
            },
            path=outPath, angle=angle, USE.NAMES=FALSE)
    }
    invisible(res)
}

#############################################
# Process the images                        #
#                                           #
#############################################

imgFiles <- dir("C:/R/Posession/Img", pattern="\\.jpg$", full=TRUE)
angle <- c(0, 45, 90)

system.time(res <- lapply(angle, processImage, files=imgFiles))

#############################################
# Load in the dataset                       #
#                                           #
#############################################

images <- read.csv("images.csv", header = TRUE, stringsAsFactors = FALSE)

#############################################
# Train the model                           #
#                                           #
#############################################

trainSize <- 20
testSize <- 4

seed <- 1234

id <- unique(images$id)
trainId <- sample(id, size=trainSize, replace=FALSE)
testId <- sample(setdiff(id, trainId), size=testSize, replace=FALSE)

trainData <- filter(images, id %in% trainId)
testData <- filter(images, id %in% testId)

# CNN model
numIterations <- 50
miniBatchSize <- 128
acceleration <- "gpu"

optim <- sgd(learningRate = 0.02, lRateRedRatio = 0.95, lRateRedFreq = 5, momentum = 0.2)

netDefinition <-
    nnlayer_input(
        c(3, 50, 50),
        name = "pixels"
    ) %>%
    nnlayer_conv(
        kernelshape = c(3, 6, 6),
        stride = c(1, 2, 2),
        sharing = c(0, 1, 1),
        activation = "rlinear",
        name = "conv1",
        mapcount = 64
    ) %>%
    nnlayer_norm(
        name = "norm1"
    ) %>%
    nnlayer_pool(
        kernelshape = c(1, 2, 2),
        stride = c(1, 2, 2),
        name = "pool1"
    ) %>%
    nnlayer_conv(
        kernelshape = c(1, 5, 5),
        stride = c(1, 2, 2),
        sharing = c(0, 1, 1),
        activation = "rlinear",
        mapcount = 2,
        name = "conv2"
    ) %>%
    nnlayer_norm(
        name = "norm2"
    ) %>%
    nnlayer_pool(
        c(1, 2, 2),
        stride = c(1, 2, 2),
        name = "pool2"
    ) %>%
    nnlayer_full(
        nodes = 128,
        name = "hid1",
        activation = "rlinear"
    ) %>%
    nnlayer_full(
        nodes = 128,
        name = "hid2",
        activation = "rlinear"
    ) %>%
    nnlayer_output(
        nodes = 2,
        name = "Class",
        activation = "softmax"
    )

# Train the model
model <- rxNeuralNet(possessed ~ pixels, data=trainData,
                type="multiClass", mlTransformVars="path",
                mlTransforms=list(
                    "BitmapLoaderTransform{col=Image:path}",
                    "BitmapScalerTransform{col=bitmap:Image width=50 height=50}",
                    "PixelExtractorTransform{col=pixels:bitmap}"
                ),
                netDefinition=netDefinition,
                optimizer=optim,
                acceleration=acceleration,
                miniBatchSize=miniBatchSize,
                numIterations=numIterations,
                normalize="no", initWtsDiameter=0.1, postTransformCache="Disk"
            )	

# (optional:) load a previously saved model
# load("model.rdata")

# predict the testdata
pred <- rxPredict(model, testData, extraVarsToWrite=c('id', 'path', 'possessed'))

# return the data with the prediction and calculate the accuracy
pred[1:4]
sum(testData$possessed == pred$PredictedLabel)/dim(pred)[1]

# (optional:) save the model
# save(model, file="model.rdata")

#############################################
# Predict based on new images               #
# Fancy looking alternative can be used     #
# through the Shiny webpage which can be    #
# found at the bottom of the code           #
#############################################

# Images should be placed in imgTest folder

# Remove the old images used for training the model
unlink("C:/R/Posession/imgProcessedNew", recursive = TRUE)

# crop and rotate the new images
imgFiles <- dir("C:/R/Posession/imgTest", pattern="\\.jpg$", full=TRUE)
angle <- c(0, 45, 90)
system.time(res <- lapply(angle, processNewImage, files=imgFiles))

# create dataframe holding the files
possessed <- c(0)
id <- c(1)
newImages <- dir("C:/R/Posession/imgProcessedNew", pattern = ".jpg$", recursive = TRUE, full=TRUE)

newImagesDF <- data.frame(basename(newImages), as.integer(id), newImages, as.integer(possessed), stringsAsFactors=FALSE)
names(newImagesDF) <- c("name", "id","path","possessed")

# perform the prediction
pred_new <- rxPredict(model, newImagesDF, extraVarsToWrite=c('name', 'path'))

# return the perdiction results (only return unique name of file)
unique(pred_new[1,1:3])

#############################################
# Start the Shiny frontend                  #
#                                           #
#############################################

library(shiny)
runApp("frontend")



